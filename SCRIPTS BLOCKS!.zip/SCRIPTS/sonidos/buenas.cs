﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class buenas : MonoBehaviour
{
    public AudioSource LevelMusic;
    // Start is called before the first frame update
    void Start()
    {
        LevelMusic.Play();
        
    }

    // Update is called once per frame
    void Update()
    {
       
    }
}
