﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sonidopelota : MonoBehaviour
{
    public AudioSource impacto;
    // Start is called before the first frame update
    void OnCollisionEnter()
    {
        impacto.Play();
    }
}
